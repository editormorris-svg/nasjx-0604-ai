# NAS Jiaxing AI Club Student Coursebook v1.2 - Print Notes

## What changed

The coursebook now uses the styled HTML/CSS as the visual source of truth for PDF production. The browser-style PDF is rendered with Chromium rather than rebuilding the page design in ReportLab.

This preserves the HTML look much more faithfully: gradients, rounded cards, teal section bars, pale panels, dashed worksheet boxes, code blocks, spacing and bilingual typography.

The v1.2 print master also restores the complete 52-page booklet structure:

- page 2: intentionally blank inside front cover
- page 5: exact Table of Contents
- page 6: Starting-Point Skills Passport
- Lessons 1-15 begin on odd-numbered right-hand pages
- Lessons 2, 6 and 8 use three teaching pages plus a notes page
- Appendix E: Final Skills Passport & Next Steps
- pages 48-51: notes / project / command / portfolio pages
- page 52: back cover

## Recommended file

Use `AI_CLUB_ECA_STUDENT_COURSEBOOK_v1.2_PRINT_READY.pdf` for printing. It is the browser-style render with subtle NAS Jiaxing footers and page numbers added in the bottom margin.

`AI_CLUB_ECA_STUDENT_COURSEBOOK_v1.2_BROWSER_STYLE.pdf` is the pure Chromium render before footer/page-number stamping.

## If printing directly from the HTML

Open the HTML in current Chrome or Edge and choose Print / Save as PDF. Use A4 portrait, 100% scale, enable Background graphics, and disable the browser's own Headers and footers. The CSS already defines the A4 page margins and page breaks.

## Booklet printing

The PDF is in logical A4 reading order and contains 52 pages (13 duplex A3 sheets when imposed as an A4 booklet). Apply booklet imposition in the printer driver or at the print shop. Print at Actual size / 100% and confirm duplex edge selection in preview before the full run.

## QA

- 52 A4 pages
- only page 2 is intentionally blank
- Lesson starts: 7, 9, 13, 15, 17, 19, 23, 25, 29, 31, 33, 35, 37, 39, 41
- Appendices A-E: 43-47
- no text blocks outside page bounds in automated preflight
- Simplified Chinese and English remain copyable/searchable
