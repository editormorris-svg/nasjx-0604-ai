# NAS Jiaxing - Practical AI for Teachers v0.1

## Facilitator guide

**Audience:** Teachers, beginner to intermediate  
**Core duration:** approximately 100 minutes  
**Flexible delivery:** 90-120 minutes  
**Portal edition:** `/pd/ai-classroom-practical`

## Learning outcomes

Participants should be able to:

1. classify an AI task by practical data/risk boundary;
2. convert a vague request into a teacher brief using **Context -> Task -> Constraints -> Check**;
3. create one small classroom resource without identifiable student information;
4. review an AI output for accuracy, fit, answers, clarity, access, rights and privacy;
5. separate low-risk assessment drafting from high-stakes human decisions;
6. choose appropriately between permitted public AI, school-managed AI and future local AI;
7. define one repeatable workflow to test and reflect on after classroom use.

## Suggested agenda

- **10 min - Set the boundary:** Green / Amber / Red task classification.
- **20 min - Brief AI well:** transform a weak prompt into a professional teaching brief.
- **25 min - Build:** create one small resource for a real upcoming lesson.
- **20 min - Review & test:** apply the seven-part QA checklist.
- **15 min - Assessment with judgement:** identify where AI can assist and where final human control remains essential.
- **10 min - Make it repeatable:** complete the one-workflow action plan.

## Facilitation notes

- Ask participants to bring a real lesson task, but instruct them to remove names, IDs and confidential details before using any general-purpose AI service.
- Treat generated material as a draft. Participants should save the first draft, then compare it with the reviewed version.
- Avoid tool evangelism. The workshop is about a transferable workflow rather than a particular vendor.
- Do not present local AI as automatically safe. Authentication, permissions, logging, routing and data handling still matter.
- Where school policy is stricter than the workshop examples, school policy wins.

## Public-release boundary

This guide and the accompanying PDF are the current NAS Jiaxing v0.1 public PD package. Legacy 0604.ai workshop PPTX/PDF files are archive evidence only and are not part of this release.
