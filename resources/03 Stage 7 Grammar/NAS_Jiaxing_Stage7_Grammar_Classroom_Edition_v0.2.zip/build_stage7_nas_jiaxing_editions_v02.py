#!/usr/bin/env python3
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import fitz  # PyMuPDF
from pypdf import PdfReader

REPO_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = REPO_ROOT / 'output/pdf'
SRC = OUTPUT_DIR / 'ZYK_Stage7_Grammar_Pilot_Complete_v0.1.pdf'
STUDENT = OUTPUT_DIR / 'NAS_Jiaxing_Stage7_Grammar_Student_Book_v0.2.pdf'
ANSWER = OUTPUT_DIR / 'NAS_Jiaxing_Stage7_Grammar_Answer_Book_v0.2.pdf'
SOURCE_BUILDER = REPO_ROOT / 'scripts/grammar-books/build_stage7_pilot_book_v01.py'

REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

PAGE_W = 595.276
PAGE_H = 841.890
NAVY = (18/255, 48/255, 74/255)
TEAL = (12/255, 116/255, 137/255)
AQUA = (221/255, 244/255, 243/255)
GOLD = (215/255, 169/255, 40/255)
INK = (29/255, 42/255, 51/255)
MUTED = (95/255, 111/255, 121/255)
PAPER = (247/255, 244/255, 236/255)
RULE = (184/255, 197/255, 204/255)
RED = (0.78, 0.0, 0.0)
PALE_RED = (1.0, 0.94, 0.94)

ITEM_RE = re.compile(r'^(?:A\d{2}|L[0-3])-\d{2}$')
ACTIVITY_RE = re.compile(r'^(?:A\d{2}|L[0-3])$')
MODULE_KEY_RE = re.compile(r'^Module\s+(\d{2}):')
MODULE_PAGE_RE = re.compile(r'MODULE\s+(\d{2})')
ITEM_BLOCK_RE = re.compile(r'((?:A\d{2}|L[0-3])-\d{2})\.')


def add_fonts(page: fitz.Page) -> None:
    page.insert_font(fontname='DVS', fontfile=REG)
    page.insert_font(fontname='DVSB', fontfile=BOLD)


def clear_page(page: fitz.Page, fill=(1, 1, 1)) -> None:
    page.add_redact_annot(page.rect, fill=fill)
    page.apply_redactions()


def text(page: fitz.Page, rect, value: str, *, size=10, bold=False, color=INK, align=0, lineheight=1.15) -> float:
    add_fonts(page)
    return page.insert_textbox(
        fitz.Rect(*rect), value, fontsize=size, fontname='DVSB' if bold else 'DVS',
        color=color, align=align, lineheight=lineheight, overlay=True
    )


def line(page: fitz.Page, x0, y0, x1, y1, color=RULE, width=0.7) -> None:
    s = page.new_shape(); s.draw_line((x0, y0), (x1, y1)); s.finish(color=color, width=width); s.commit()


def filled_rect(page: fitz.Page, rect, fill, stroke=None, width=0.5, radius=None) -> None:
    s = page.new_shape(); s.draw_rect(fitz.Rect(*rect)); s.finish(fill=fill, color=stroke, width=width); s.commit()


def footer(page: fitz.Page, page_no: int, background=(1,1,1)) -> None:
    # Remove the old left footer text but keep the page number and horizontal rule.
    for r in page.search_for('ZYK Stage 7 Grammar'):
        rr = fitz.Rect(r.x0 - 2, r.y0 - 2, 235, r.y1 + 2)
        page.add_redact_annot(rr, fill=background)
    page.apply_redactions()
    add_fonts(page)
    page.insert_text((45.35, 821.9), 'NAS Jiaxing · English Department', fontsize=7.4, fontname='DVS', color=MUTED, overlay=True)


def draw_cover(page: fitz.Page, *, answer=False) -> None:
    clear_page(page, NAVY)
    # Full navy field with teal identity band and gold spine rule.
    filled_rect(page, (0, 124, PAGE_W, 176), TEAL)
    filled_rect(page, (50, 133, 64, 730), GOLD)
    text(page, (87, 132, 548, 166), 'NAS JIAXING', size=20, bold=True, color=(1,1,1))
    text(page, (87, 166, 548, 191), 'ENGLISH DEPARTMENT', size=9.5, bold=True, color=(1,1,1))
    text(page, (87, 230, 540, 288), 'STAGE 7', size=39, bold=True, color=(1,1,1))
    text(page, (87, 290, 540, 330), 'Complete Grammar Book', size=22, bold=True, color=(1,1,1))
    if answer:
        text(page, (87, 353, 540, 390), 'ANSWER BOOK', size=17, bold=True, color=GOLD)
        text(page, (87, 391, 535, 434), 'Full student pages with answers and scoring guidance shown in red.', size=10.5, color=(0.90,0.94,0.97), lineheight=1.25)
    else:
        text(page, (87, 353, 540, 390), 'STUDENT BOOK', size=17, bold=True, color=GOLD)
        text(page, (87, 391, 535, 434), '24 modules · practice · retrieval · reflection', size=10.5, color=(0.90,0.94,0.97))
    text(page, (87, 670, 535, 700), 'CLASSROOM EDITION v0.2', size=11.5, bold=True, color=GOLD)
    text(page, (87, 704, 535, 730), 'Prepared for classroom use and sample-group testing', size=9.5, color=(0.90,0.94,0.97))
    line(page, 45, 807, 550, 807, color=RULE, width=0.7)
    text(page, (45, 811, 410, 828), 'NAS Jiaxing · English Department', size=7.4, color=(0.60,0.70,0.76))
    text(page, (535, 811, 552, 828), '1', size=7.4, color=(0.60,0.70,0.76), align=2)


def draw_how_to(page: fitz.Page, *, answer=False) -> None:
    clear_page(page, PAPER)
    text(page, (50, 54, 545, 105), 'How to use this answer book' if answer else 'How to use this book', size=23, bold=True, color=NAVY)
    boxes = []
    if answer:
        boxes = [
            'This volume reproduces the complete student book. Every printed answer or scoring note is added directly to the learner page in red.',
            'For fixed-answer items, the expected answer is shown beside the response space. For open tasks, the red note gives a model, acceptable response type, or scoring criteria.',
            'Keep the student book separate during first attempts. Use this answer volume for checking, feedback, reteaching and moderation.',
            'Equivalent accurate British-English responses are acceptable unless an item is testing a specific contrast.',
            'Page numbers match the student book exactly, so both books can be used side by side.'
        ]
    else:
        boxes = [
            'Work through the modules in order. Each module follows Learn → Notice → Build → Choose → Use → Check → Retrieve → Reflect.',
            'Write your first answer in the space provided. Do not worry about being perfect: your first attempt is useful evidence of what you already know.',
            'After feedback, correct your work and explain one important change. Then return to the language later through the retrieval tasks.',
            'Use the module progress check to record what feels secure and what still needs another return.',
            'The book is designed for A4 portrait printing, duplex, long-edge, at 100% / actual size.'
        ]
    y = 136
    for b in boxes:
        filled_rect(page, (50, y, 545, y+72), AQUA)
        text(page, (67, y+17, 526, y+58), b, size=9.4, color=INK, lineheight=1.25)
        y += 86
    text(page, (50, 750, 545, 778), '24 modules · 360 activities · 2,452 learner items', size=8.2, color=MUTED)
    line(page, 45, 807, 550, 807, color=RULE, width=0.7)
    text(page, (45, 811, 420, 828), 'NAS Jiaxing · English Department', size=7.4, color=MUTED)
    text(page, (535, 811, 552, 828), '2', size=7.4, color=MUTED, align=2)


def draw_student_record(page: fitz.Page) -> None:
    clear_page(page, (1,1,1))
    text(page, (50, 55, 545, 100), 'My grammar learning record', size=23, bold=True, color=NAVY)
    prompts = [
        'Modules I have completed:',
        'Something I can now do independently:',
        'A grammar pattern I still confuse:',
        'One correction I can explain clearly:',
        'One example I want to remember:'
    ]
    y=126
    for p in prompts:
        text(page, (50,y,545,y+28), p, size=10.2, bold=True, color=TEAL)
        for j in range(3): line(page, 50, y+42+j*23, 545, y+42+j*23)
        y += 124
    line(page, 45, 807, 550, 807, color=RULE, width=0.7)
    text(page, (45,811,420,828), 'NAS Jiaxing · English Department', size=7.4, color=MUTED)
    text(page, (535,811,552,828), '244', size=7.4, color=MUTED, align=2)


def draw_progress_summary(page: fitz.Page) -> None:
    clear_page(page, (1,1,1))
    text(page, (50, 55, 545, 100), 'Stage 7 progress summary', size=23, bold=True, color=NAVY)
    prompts = [
        'Modules completed:', 'My strongest evidence:', 'Patterns needing another return:',
        'A transfer task I completed:', 'My next step:', 'My next grammar goal:'
    ]
    y=124
    for p in prompts:
        text(page, (50,y,545,y+25), p, size=10.2, bold=True, color=TEAL)
        for j in range(2 if p in ('Modules completed:','My next step:','My next grammar goal:') else 3):
            line(page, 50, y+37+j*22, 545, y+37+j*22)
        y += 102 if p in ('Modules completed:','My next step:','My next grammar goal:') else 120
    line(page, 45, 807, 550, 807, color=RULE, width=0.7)
    text(page, (45,811,420,828), 'NAS Jiaxing · English Department', size=7.4, color=MUTED)
    text(page, (535,811,552,828), '246', size=7.4, color=MUTED, align=2)


def draw_notes(page: fitz.Page) -> None:
    clear_page(page, (1,1,1))
    text(page, (50, 55, 545, 100), 'My notes', size=23, bold=True, color=NAVY)
    text(page, (50, 122, 545, 150), 'Examples, corrections, questions and reminders:', size=10.2, bold=True, color=TEAL)
    y=168
    for _ in range(22):
        line(page, 50, y, 545, y)
        y += 26
    line(page, 45, 807, 550, 807, color=RULE, width=0.7)
    text(page, (45,811,420,828), 'NAS Jiaxing · English Department', size=7.4, color=MUTED)
    text(page, (535,811,552,828), '247', size=7.4, color=MUTED, align=2)


def patch_page6(page: fitz.Page) -> None:
    target='One speaking or writing goal for this pilot:'
    rs=page.search_for(target)
    if rs:
        for r in rs:
            rr=fitz.Rect(r.x0-1, r.y0-2, r.x1+4, r.y1+2)
            page.add_redact_annot(rr, fill=(1,1,1))
        page.apply_redactions()
        add_fonts(page)
        # Same baseline position and approximate styling as original.
        page.insert_text((50.8, rs[0].y1-0.5), 'One speaking or writing goal for this book:', fontsize=10.4, fontname='DVSB', color=TEAL, overlay=True)


def rebrand_student(source: Path, out: Path, *, answer_cover=False) -> None:
    src = fitz.open(source)
    doc = fitz.open()
    doc.insert_pdf(src, from_page=0, to_page=246)  # exact student range 1-247
    # Full redraw of pages that contained publication/teacher/pilot-only material.
    draw_cover(doc[0], answer=answer_cover)
    draw_how_to(doc[1], answer=answer_cover)
    draw_student_record(doc[243])
    draw_progress_summary(doc[245])
    draw_notes(doc[246])
    patch_page6(doc[5])

    # Replace all remaining ZYK running-footers without changing page numbers/layout.
    for idx, page in enumerate(doc):
        if idx in (0,1,243,245,246):
            continue
        bg = PAPER if idx in (2,3,4) else (1,1,1)
        footer(page, idx+1, background=bg)

    meta = doc.metadata or {}
    meta.update({
        'title': 'NAS Jiaxing Stage 7 Grammar Answer Book' if answer_cover else 'NAS Jiaxing Stage 7 Grammar Student Book',
        'author': 'NAS Jiaxing English Department',
        'subject': 'Stage 7 Grammar - classroom edition',
        'keywords': 'NAS Jiaxing, English Department, grammar, Stage 7',
        'creator': 'NAS Jiaxing English Department',
        'producer': 'NAS Jiaxing English Department',
    })
    doc.set_metadata(meta)
    doc.save(out, garbage=4, deflate=True, clean=True)
    doc.close(); src.close()


def parse_answers(source: Path):
    reader=PdfReader(str(source))
    answers={}
    current=None
    for pno in range(248,334):  # source pages 249-334, zero-based
        lines=[x.strip() for x in (reader.pages[pno].extract_text() or '').splitlines()]
        i=0
        while i<len(lines):
            m=MODULE_KEY_RE.match(lines[i])
            if m:
                current=int(m.group(1)); i+=1; continue
            if current and ITEM_RE.match(lines[i]):
                iid=lines[i]; i+=1; buf=[]
                while i<len(lines):
                    s=lines[i]
                    if MODULE_KEY_RE.match(s) or ITEM_RE.match(s) or ACTIVITY_RE.match(s) or s.startswith('Teacher Reference') or s.isdigit() or s in ('Item','Expected answer / scoring guidance'):
                        break
                    if s: buf.append(s)
                    i+=1
                answers[(current,iid)]=' '.join(buf).strip()
                continue
            i+=1
    return answers


def compact_answer(ans: str) -> str:
    # Preserve all substantive guidance while making the inline answer more print-friendly.
    ans = ans.replace(' — ', ' - ').replace('–', '-').replace('→', '->')
    ans = re.sub(r'\s+', ' ', ans).strip()
    if ans.startswith('Open response. Rubric: '):
        ans = 'Open response - ' + ans[len('Open response. Rubric: '):]
    elif ' Rubric: ' in ans:
        ans = ans.replace(' Rubric: ', ' | Criteria: ')
    return ans


def response_lines(page: fitz.Page):
    ys=[]
    for d in page.get_drawings():
        r=d['rect']
        if abs(r.x0-55.2756)<2.5 and abs(r.x1-540.0)<3.5 and abs(r.y1-r.y0)<0.6 and 80<r.y0<805:
            ys.append(r.y0)
    return sorted(ys)


def add_answers(source: Path, answer_pdf: Path) -> dict:
    answers=parse_answers(source)
    src=fitz.open(source)
    doc=fitz.open(answer_pdf)
    current=None
    inserted=0
    smallest=99.0
    unresolved=[]
    for pno in range(6,243):  # module pages 7-243
        sp=src[pno]
        page=doc[pno]
        m=MODULE_PAGE_RE.search(sp.get_text())
        if m: current=int(m.group(1))
        if current is None: continue
        blocks=sp.get_text('blocks')
        items=[]
        for b in blocks:
            x0,y0,x1,y1,bt,*_=b
            mm=ITEM_BLOCK_RE.match(bt.strip())
            if mm:
                items.append((y0,y1,mm.group(1),fitz.Rect(x0,y0,x1,y1),bt))
        items.sort(key=lambda x:x[0])
        rlines=response_lines(sp)
        add_fonts(page)
        for idx,(y0,y1,iid,irect,bt) in enumerate(items):
            ans=answers.get((current,iid))
            if not ans:
                unresolved.append((current,iid,pno+1,'missing answer')); continue
            nexty=items[idx+1][0] if idx+1<len(items) else 800
            lines=[y for y in rlines if y>y1 and y<nexty]
            if not lines:
                unresolved.append((current,iid,pno+1,'missing response line')); continue
            first=min(lines); last=max(lines)
            content_end=y1
            # Capture wrapped prompt/options text before the first response line.
            for b in blocks:
                bx0,by0,bx1,by1,btext,*_=b
                if by0 >= y0-0.5 and by0 < first and by1 <= first+0.5:
                    content_end=max(content_end,by1)
            top=content_end+1.0
            bottom=last-1.2
            if bottom-top < 5.5:
                top=max(content_end, first-7.5)
                bottom=last-0.5
            rect=fitz.Rect(58, top, 538, bottom)
            label='Answer: '+compact_answer(ans)
            # Add a light white wash over the writing line area only; the original question remains untouched.
            # This keeps long red guidance readable while preserving the full student page.
            page.draw_rect(rect, color=None, fill=(1,1,1), fill_opacity=0.84, overlay=True)
            fit=False
            for size in (7.2,6.8,6.4,6.0,5.6,5.2,4.8,4.4,4.0):
                spare=page.insert_textbox(rect, label, fontsize=size, fontname='DVS', color=RED, lineheight=1.02, overlay=True)
                if spare >= -0.05:
                    smallest=min(smallest,size); fit=True; break
                # failed insert_textbox draws nothing in current PyMuPDF when it does not fit
            if not fit:
                unresolved.append((current,iid,pno+1,'text overflow'))
            else:
                inserted+=1
    # Answer-volume metadata.
    meta=doc.metadata or {}
    meta['title']='NAS Jiaxing Stage 7 Grammar Answer Book'
    meta['author']='NAS Jiaxing English Department'
    meta['subject']='Complete student book with answers in red'
    doc.set_metadata(meta)
    tmp=answer_pdf.with_suffix('.tmp.pdf')
    doc.save(tmp, garbage=4, deflate=True, clean=True)
    doc.close(); src.close()
    tmp.replace(answer_pdf)
    return {'answers_parsed':len(answers),'answers_inserted':inserted,'smallest_font':smallest,'unresolved':unresolved}


def verify_no_zyk(path: Path) -> list[int]:
    r=PdfReader(str(path)); bad=[]
    for i,p in enumerate(r.pages,1):
        t=p.extract_text() or ''
        if 'ZYK' in t:
            bad.append(i)
    return bad


def ensure_source() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    if SRC.exists():
        return
    subprocess.run([sys.executable, str(SOURCE_BUILDER)], cwd=REPO_ROOT, check=True)
    if not SRC.exists():
        raise FileNotFoundError(f'Source pilot PDF was not produced: {SRC}')


def main():
    ensure_source()
    rebrand_student(SRC, STUDENT, answer_cover=False)
    rebrand_student(SRC, ANSWER, answer_cover=True)
    stats=add_answers(SRC, ANSWER)
    print('student', STUDENT)
    print('answer', ANSWER)
    print(stats)
    print('student pages with ZYK:', verify_no_zyk(STUDENT)[:20])
    print('answer pages with ZYK:', verify_no_zyk(ANSWER)[:20])

if __name__=='__main__':
    main()
