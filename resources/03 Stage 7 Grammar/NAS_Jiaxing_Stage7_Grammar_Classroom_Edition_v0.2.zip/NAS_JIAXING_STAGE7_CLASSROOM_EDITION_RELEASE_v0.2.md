# NAS Jiaxing Stage 7 Grammar Classroom Edition — Release Record v0.2

Release date: 2026-08-28  
Source: the completed governed Stage 7 publication build generated from the 24 canonical module production records  
Publication identity: **NAS Jiaxing · English Department**

## Purpose

This release creates a school-facing classroom edition of the completed Stage 7 grammar book without changing the governed grammar content. It separates learner and answer use into two parallel books with identical page numbering.

## Student Book

`NAS_Jiaxing_Stage7_Grammar_Student_Book_v0.2.pdf`

- 247 A4 portrait pages;
- 24 complete modules, 360 activities and 2,452 learner items;
- no detached teacher-reference section;
- no answer key or answer content;
- no remaining visible/extracted `ZYK` text reference;
- cover and running identity changed to **NAS JIAXING** + **ENGLISH DEPARTMENT**;
- the former publication/teacher-facing guide is replaced by a learner-facing `How to use this book` page;
- staff-only end pages are replaced by learner-facing grammar record, progress and notes pages;
- the starting-point wording `for this pilot` is changed to `for this book`.

SHA-256: `1efcfbafd0d7f6228468b9aee688bfb939e9923711f50417ed203c182cda5759`

## Answer Book

`NAS_Jiaxing_Stage7_Grammar_Answer_Book_v0.2.pdf`

- 247 A4 portrait pages;
- reproduces the full student book page-for-page;
- page numbers match the student book exactly;
- all 2,452 teacher-key answers/scoring guidance entries are parsed from the completed source publication and placed directly into the corresponding learner response spaces;
- answers and scoring notes are printed in red;
- fixed-response items show the expected answer directly beside/below the item;
- open-production items show the governed model/acceptable response type/rubric guidance rather than a detached item-reference list;
- 2,452/2,452 answer placements resolved; zero missing or overflow placements;
- no remaining visible/extracted `ZYK` text reference.

SHA-256: `09607db12ed5fba7aa683bd23a4366159834b75d4f1e9594d434c6805b13bce9`

## Reproducible build

Run the existing Stage 7 pilot builder first, or run the classroom-edition builder directly; the latter will build the source pilot automatically when it is absent:

```bash
python scripts/grammar-books/build_stage7_nas_jiaxing_editions_v02.py
```

The generated PDFs remain outside Git source control under `output/pdf/`. The source script and release/manifest records are canonical in GitHub; finished binary deliverables belong in the private archive/release layer.

## QA

- source pilot verified against SHA-256 `ac6793e3068c90545b21415acc4ea7048bcb52604ae5cecf7761ac9ec8459e8e`;
- both output books contain exactly 247 pages;
- PDF preflight: openable, unencrypted, A4 portrait, non-scanned, no XFA;
- automated text scan found zero `ZYK` hits in either output;
- answer reconciliation: 2,452 parsed / 2,452 inserted / 0 unresolved;
- representative cover, front-matter, module, dense-answer and end-matter pages were rendered and visually inspected for clipping and overlap;
- the densest inline-answer pages remain within the original response areas.

## Governance and evidence boundary

This is a publication-layer classroom adaptation only. It does **not** alter the 24 canonical module records, approved grammar banks, Grammar Mastery Progression Map, approved-bank crosswalk, SPIRAL methodology, learning outcomes, item IDs or textbook/Cambridge evidence claims. Exact textbook-specific alignment remains governed by D-016/D-020.
