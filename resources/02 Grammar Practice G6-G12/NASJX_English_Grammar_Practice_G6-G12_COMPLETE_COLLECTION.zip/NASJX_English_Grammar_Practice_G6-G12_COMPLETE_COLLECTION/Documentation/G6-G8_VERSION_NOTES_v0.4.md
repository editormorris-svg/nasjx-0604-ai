# NASJX English Grammar Practice - G6-G8

Version: v0.4 classroom working edition  
Date: 2026-08-16  
Department: NASJX English Department  
Teacher: William Morris

## Included books

- G6 Student Book: 60 pages, 16 grammar units, mixed reviews and final review.
- G6 Teacher Answer Key: 13 pages.
- G7 Student Book: 63 pages, 17 grammar units, mixed reviews and final review.
- G7 Teacher Answer Key: 13 pages.
- G8 Student Book: 71 pages, 19 grammar units, mixed reviews and final review.
- G8 Teacher Answer Key: 15 pages.

## Classroom design

- English + Simplified Chinese explanation where conceptual support is useful.
- English examples remain the primary model language.
- Multiple-choice options use bracket labels: (A), (B), (C), (D).
- MCQ answer positions are deliberately balanced rather than left in obvious patterns.
- Local and ESL-neutral contexts are preferred (school, Jiaxing, Hangzhou, Suzhou, transport, daily life).
- Student writing areas use full-width ruled lines and additional vertical space for longer responses.
- Each unit moves from explanation to controlled choice/building, correction/improvement, independent use and later mixed review.
- Teacher keys accept other natural answers when a prompt genuinely permits them.

## Version history

Earlier working versions remain retained separately for rollback. v0.4 is the current classroom edition.
