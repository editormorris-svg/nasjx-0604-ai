# NASJX English Grammar Practice G9-G12 v0.1 - QA Report

Date: 2026-08-24  
Status: **PASS**

## Coverage

| Grade | Units | Grammar concepts checked | Unique model examples | Student PDF | Teacher-key PDF |
| --- | ---: | ---: | ---: | ---: | ---: |
| G9 | 21 | 84 | 84 | 78 A4 pages | 26 A4 pages |
| G10 | 21 | 84 | 84 | 78 A4 pages | 26 A4 pages |
| G11 | 21 | 84 | 84 | 78 A4 pages | 26 A4 pages |
| G12 | 21 | 84 | 84 | 78 A4 pages | 26 A4 pages |

## Checks passed

- All four grade content records contain 21 sequential units and four complete bilingual concepts per unit.
- Every mapped unit retains an approved grammar-production transfer and at least three items from its canonical stage vocabulary bank.
- All 336 model examples are unique within their grade record; every target appears exactly once in its model sentence.
- All eight DOCX files pass ZIP/package integrity checks and contain the required document and style parts.
- All eight PDFs have the expected page count and A4 page size.
- Noto Sans SC is embedded/subset in every PDF; Simplified Chinese rendered correctly in the visual review.
- No blank or near-blank pages were found.
- No TODO, TBD, placeholder, citation-token or replacement-glyph residue was found.
- Every student book contains 21 Practice 1 sections, 21 Practice 2 sections, Reviews 1-3 and the Final Mixed Review.
- Every teacher key contains answers for Units 1-21, Reviews 1-3 and the final review.
- 216 mixed-review multiple-choice items were checked for three distinct options and exactly one recorded correct option.
- Review distractors use a consistent invalid auxiliary pattern or an incomplete dependent clause; the answer option remains unambiguous.
- Student and teacher-key PDFs passed contact-sheet visual inspection for page order, clipping, overflow, bilingual rendering and writing-space consistency.

## Draft-review-repair record

1. **Draft:** generated the G9-G12 student books and teacher keys from the validated 21-unit transfer records.
2. **Structured self-review:** validated unit counts, concept fields, bilingual support, target placement, vocabulary mapping, page counts, font embedding and page images.
3. **Repair:** replaced potentially ambiguous mixed-review distractors with guaranteed structural errors and made open rewrite prompts name their intended grammar target.
4. **Canonical v0.1:** regenerated all formats and reran the complete artifact and visual QA suite.

## Machine-readable evidence

The pack includes `final_artifact_qa.json`, which records the per-file checks,
page metadata and review-item totals used for the final pass decision.

## Scope note

This QA decision covers the practical G9-G12 classroom series only. It does not
approve or replace content in the governed G6-G12 24-module production
architecture.
