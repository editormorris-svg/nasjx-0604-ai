# NASJX English Grammar Practice - G9-G12

Version: v0.1 classroom working edition  
Date: 2026-08-24  
Department: NASJX English Department  
Teacher: William Morris

## Series boundary

This pack continues the practical classroom-book line established by
`NASJX_English_Grammar_Practice_G6-G8_v0.4_COMPLETE_PACK.zip`. It is not the
newer governed `docs/phase-2/grammar-books/` 24-module production architecture.
The practical format is retained while the upper-grade grammar scope is drawn
from the approved G9-G12 progression records.

## Included books

- G9 Student Book: 78 A4 pages, 21 grammar units, three cumulative reviews and a final mixed review.
- G9 Teacher Answer Key: 26 A4 pages.
- G10 Student Book: 78 A4 pages, 21 grammar units, three cumulative reviews and a final mixed review.
- G10 Teacher Answer Key: 26 A4 pages.
- G11 Student Book: 78 A4 pages, 21 grammar units, three cumulative reviews and a final mixed review.
- G11 Teacher Answer Key: 26 A4 pages.
- G12 Student Book: 78 A4 pages, 21 grammar units, three cumulative reviews and a final mixed review.
- G12 Teacher Answer Key: 26 A4 pages.
- Every book and teacher key is supplied in both DOCX and PDF.

## Practical-book structure

- Each grade contains 21 teachable units in three seven-unit blocks.
- Each unit has one bilingual learning page, one controlled-practice page and one repair/use page.
- Review 1 follows Units 1-7, Review 2 follows Units 8-14, and Review 3 follows Units 15-21.
- A separate final mixed review samples the whole grade.
- Student books preserve the G6-G8 practical series' Meaning → Form → Use orientation.
- English remains the model language; Simplified Chinese supports concept access and directions.
- Stage-bank vocabulary is used as optional production support, not as a replacement for the grammar objective.
- Teacher keys give controlled answers, suggested corrections, teaching focus notes and open-answer guidance.

## Canonical scope transfer

The GitHub grammar progression remains the source of scope. For this practical
format, governed grammar modules 1-7, 9-15 and 17-23 become the 21 classroom
units. Governed transfer modules 8, 16 and 24 become the three cumulative
reviews and final-review sequence.

| Practical grade | ZYK stage | Grammar source | Vocabulary source |
| --- | --- | --- | --- |
| G9 | Stage 10 | G6-G12 Grammar Mastery Progression Map | Canonical Stage 10 bank |
| G10 | Stage 11 | G6-G12 Grammar Mastery Progression Map | Canonical Stage 11 bank |
| G11 | Stage 12 | G6-G12 Grammar Mastery Progression Map | Canonical Stage 12 bank |
| G12 | Stage 13 | G6-G12 Grammar Mastery Progression Map | Canonical Stage 13 bank |

The Stage 13 vocabulary bank was confirmed on canonical GitHub `main` before
G12 production. Its repository blob SHA is
`6882049ade991c84f752425cff3bcdf23c951304`.

## Source provenance

- Practical reference pack SHA-256: `0249c115817810fe592ce2730ec755c1917c07ebf427d270c60fe98474bfc07f`
- Grammar progression blob SHA: `f532d390849dfabe78c2439006c783efe06d9662`
- Stage 10 vocabulary blob SHA: `cc36a08ce6e1e87747ca55a244054884e160843a`
- Stage 11 vocabulary blob SHA: `bf52d0d2cb9453e8651a93f533c9a90052cf21e6`
- Stage 12 vocabulary blob SHA: `ef13877a89e6025051919c038fb90c6963b01bf1`
- Stage 13 vocabulary blob SHA: `6882049ade991c84f752425cff3bcdf23c951304`
- Canonical transfer record SHA-256: `a293257defc7594b420ba7a136713208e7f2b22e46d6325f18e85e72efa8dd87`

## QA status

The v0.1 pack passed content-structure, artifact-integrity, review-option,
page-count, A4-size, font-embedding, required-section, blank-page, placeholder
and visual-layout checks. Full details are in
`NASJX_English_Grammar_Practice_G9-G12_v0.1_QA_REPORT.md`.

## Version history

v0.1 is the first complete practical classroom edition for G9-G12. It extends
the G6-G8 v0.4 line without modifying the approved source pack or the governed
24-module architecture.
